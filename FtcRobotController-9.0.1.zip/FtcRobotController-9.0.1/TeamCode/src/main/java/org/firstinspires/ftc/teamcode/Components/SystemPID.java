package org.firstinspires.ftc.teamcode.Components;

import com.qualcomm.robotcore.hardware.DcMotorEx;
public class SystemPID {
    DcMotorEx motor = null;
    double motorTicks = 0;
    double kP = 0;
    double kI = 0;
    double kD = 0;
    double degrees = 0;

    public SystemPID(DcMotorEx motor, double motorTicks, double p, double i, double d, double degrees) {
        this.motor = motor;
        this.motorTicks = motorTicks;
        kP = p;
        kI = i;
        kD = d;
        this.degrees = degrees;
    }

    private double getCurrentPosition() {return motor.getCurrentPosition();}
    private double getAbsoluteAngle = getCurrentPosition() * (360 / motorTicks);
     void runTo(double targetAngle) {
        PIDController pid = new PIDController(targetAngle, kP, kI, kD);
        while (Math.abs(targetAngle - getAbsoluteAngle) > 1) {
            double motorPower = pid.update(getAbsoluteAngle);
            motor.setPower(motorPower);
        }
        motor.setPower(0);
    }

    public void run() {
        runTo(degrees - getAbsoluteAngle);
    }
}
