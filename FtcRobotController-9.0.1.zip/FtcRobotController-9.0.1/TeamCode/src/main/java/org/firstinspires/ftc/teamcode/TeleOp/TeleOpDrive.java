package org.firstinspires.ftc.teamcode.TeleOp;

import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.Gamepad;

import org.firstinspires.ftc.teamcode.Components.Hardware;
import org.firstinspires.ftc.teamcode.Constants.MotorConstants;

@TeleOp
public class TeleOpDrive extends LinearOpMode {

    private Hardware robot = null;

    private Gamepad chassisDriver = null, systemDriver = null;

    @Override
    public void runOpMode() throws InterruptedException {
        robot = new Hardware(hardwareMap, Hardware.Stage.TELEOP);

        chassisDriver = gamepad1;
        systemDriver  = gamepad2;

        waitForStart();

        if (opModeIsActive() && !isStopRequested()) {
            while (opModeIsActive() && !isStopRequested()) {
                driveControl(chassisDriver);
                systemControl(systemDriver);
            }
        }
    }

    private void driveControl(Gamepad driver) {
        double fRotate = 0;
        double kStickLimit = 0;
        double stick_x = 0;
        double stick_y = 0;

        double yaw = 0;

        double theta = 0;
        double magnitude = 0;
        double fX = 0;
        double fY = 0;

        double flPower = 0, frPower = 0;
        double blPower = 0, brPower = 0;

        fRotate = -driver.right_stick_x * 0.5;
        kStickLimit = Math.sqrt(Math.pow(1 - Math.abs(fRotate), 2) / 2);
        stick_x = driver.left_stick_x * kStickLimit;
        stick_y = -driver.left_stick_y * kStickLimit;

        if (driver.right_bumper) robot.reset_angle += robot.rawHeading();

        yaw = robot.radHeading();

        theta = Math.atan2(stick_y, stick_x) - yaw - (Math.PI / 2);
        magnitude = Math.hypot(stick_x, stick_y);
        fX = magnitude * Math.sin(theta + Math.PI / 4);
        fY = magnitude * Math.sin(theta - Math.PI / 4);

        flPower = (fY - fRotate) * MotorConstants.kDriveMotorSpeedConstant;
        frPower = (fX + fRotate) * MotorConstants.kDriveMotorSpeedConstant;
        blPower = (fX - fRotate) * MotorConstants.kDriveMotorSpeedConstant;
        brPower = (fY + fRotate) * MotorConstants.kDriveMotorSpeedConstant;

        robot.fl.setPower(flPower);
        robot.fr.setPower(frPower);
        robot.bl.setPower(blPower);
        robot.br.setPower(brPower);

        if (driver.dpad_up) {//
            robot.planeServo.setPower(0.5);
        } else if (driver.dpad_down) {//
            robot.planeServo.setPower(-0.5);
        } else {//
            robot.planeServo.setPower(0);
        }
    }

    private void systemControl(Gamepad system) {//
        robot.pixelLift.setPower(system.left_stick_y * 0.5);

        if (system.dpad_down) {//
            robot.intakeMotor.setPower(-0.6);
        } else if (system.dpad_up) {//
            robot.intakeMotor.setPower(0.6);
        } else {//
            robot.intakeMotor.setPower(0);
        }
        if (system.left_bumper) {//
            robot.intakeServo.setPosition(0.8);
        } else if (system.right_bumper) {//
            robot.intakeServo.setPosition(1);
        }

        robot.pixelServo.setPower(system.right_stick_y * 0.5);

        double armLiftVelocity = 0;

        armLiftVelocity = (system.right_trigger - system.left_trigger) * MotorConstants.kArmLiftTicks * MotorConstants.kArmSpeedConstant;

        robot.setArmLiftVelocity(armLiftVelocity);
    }
}
