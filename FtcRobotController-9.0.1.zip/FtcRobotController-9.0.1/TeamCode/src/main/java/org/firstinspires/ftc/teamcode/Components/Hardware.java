package org.firstinspires.ftc.teamcode.Components;

import com.qualcomm.hardware.bosch.BNO055IMU;
import com.qualcomm.robotcore.hardware.CRServo;
import com.qualcomm.robotcore.hardware.DcMotorEx;
import com.qualcomm.robotcore.hardware.HardwareMap;
import com.qualcomm.robotcore.hardware.Servo;

import org.firstinspires.ftc.robotcore.external.navigation.AngleUnit;
import org.firstinspires.ftc.robotcore.external.navigation.AxesOrder;
import org.firstinspires.ftc.robotcore.external.navigation.AxesReference;
import org.firstinspires.ftc.teamcode.Constants.Names;

public class Hardware {

    public DcMotorEx fl = null, fr = null, bl = null, br = null;
    public DcMotorEx intakeMotor = null, pixelLift = null;
    public DcMotorEx leftArmLift = null, rightArmLift = null;

    public Servo intakeServo = null;
    public CRServo pixelServo = null, planeServo = null;
    public BNO055IMU imu = null;

    private SystemPID pid = null;

    public enum Stage {AUTONOMOUS, TELEOP}
    Stage stage;

    private HardwareMap hwMap;

    public Hardware(HardwareMap hwMap, Stage stage) {
        this.hwMap = hwMap;
        this.stage = stage;
        init();
    }

    private void init() {
        fl = hwMap.get(DcMotorEx.class, Names.kFL);
        fr = hwMap.get(DcMotorEx.class, Names.kFR);
        bl = hwMap.get(DcMotorEx.class, Names.kBL);
        br = hwMap.get(DcMotorEx.class, Names.kBR);

        fl.setDirection(DcMotorEx.Direction.REVERSE);
        fr.setDirection(DcMotorEx.Direction.FORWARD);
        bl.setDirection(DcMotorEx.Direction.REVERSE);
        br.setDirection(DcMotorEx.Direction.FORWARD);

        switch (stage) {
            case AUTONOMOUS:
                fl.setMode(DcMotorEx.RunMode.RUN_USING_ENCODER);
                fr.setMode(DcMotorEx.RunMode.RUN_USING_ENCODER);
                bl.setMode(DcMotorEx.RunMode.RUN_USING_ENCODER);
                br.setMode(DcMotorEx.RunMode.RUN_USING_ENCODER);

                fl.setZeroPowerBehavior(DcMotorEx.ZeroPowerBehavior.FLOAT);
                fr.setZeroPowerBehavior(DcMotorEx.ZeroPowerBehavior.FLOAT);
                bl.setZeroPowerBehavior(DcMotorEx.ZeroPowerBehavior.FLOAT);
                br.setZeroPowerBehavior(DcMotorEx.ZeroPowerBehavior.FLOAT);
                break;
            case TELEOP:
                fl.setMode(DcMotorEx.RunMode.RUN_WITHOUT_ENCODER);
                fr.setMode(DcMotorEx.RunMode.RUN_WITHOUT_ENCODER);
                bl.setMode(DcMotorEx.RunMode.RUN_WITHOUT_ENCODER);
                br.setMode(DcMotorEx.RunMode.RUN_WITHOUT_ENCODER);

                fl.setZeroPowerBehavior(DcMotorEx.ZeroPowerBehavior.BRAKE);
                fr.setZeroPowerBehavior(DcMotorEx.ZeroPowerBehavior.BRAKE);
                bl.setZeroPowerBehavior(DcMotorEx.ZeroPowerBehavior.BRAKE);
                br.setZeroPowerBehavior(DcMotorEx.ZeroPowerBehavior.BRAKE);
                break;
        }

        imu = hwMap.get(BNO055IMU.class, Names.kIMU);

        BNO055IMU.Parameters parameters        = new BNO055IMU.Parameters();
        parameters.mode                        = BNO055IMU.SensorMode.IMU;
        parameters.angleUnit                   = BNO055IMU.AngleUnit.DEGREES;
        parameters.accelUnit                   = BNO055IMU.AccelUnit.METERS_PERSEC_PERSEC;
        parameters.loggingEnabled              = false;
        imu.initialize(parameters);


        intakeMotor = hwMap.get(DcMotorEx.class, Names.kIntakeMotor);
        intakeMotor.setDirection(DcMotorEx.Direction.REVERSE);
        intakeMotor.setMode(DcMotorEx.RunMode.STOP_AND_RESET_ENCODER);
        intakeMotor.setMode(DcMotorEx.RunMode.RUN_WITHOUT_ENCODER);

        pixelLift = hwMap.get(DcMotorEx.class, Names.kPixelLift);

        leftArmLift = hwMap.get(DcMotorEx.class, Names.kLeftArmLift);
        rightArmLift = hwMap.get(DcMotorEx.class, Names.kRightArmLift);

        leftArmLift.setDirection(DcMotorEx.Direction.REVERSE);
        rightArmLift.setDirection(DcMotorEx.Direction.REVERSE);

        intakeServo = hwMap.get(Servo.class, Names.kIntakeServo);

        intakeServo.setDirection(Servo.Direction.FORWARD);

        pixelServo = hwMap.get(CRServo.class, Names.kPixelServo);

        planeServo = hwMap.get(CRServo.class, Names.kPlaneServo);

        planeServo.setDirection(DcMotorEx.Direction.REVERSE);
    }

    public void setAllDriveMotorPower(double p) {setDriveMotorPower(p, p, p, p);}
    public void setDriveMotorPower(double flP, double frP, double blP, double brP) {
        fl.setPower(flP);
        fr.setPower(frP);
        bl.setPower(blP);
        br.setPower(brP);
    }
    public double reset_angle = 0;

    public double rawHeading() {
        double heading = 0;

        heading = imu.getAngularOrientation(//
                AxesReference.INTRINSIC, AxesOrder.ZYX, AngleUnit.DEGREES//
        ).firstAngle;

        if (heading < -180) {
            heading += 360;
        } else if (heading > 180){
            heading -= 360;
        }

        heading -= reset_angle;

        return heading;
    }

    public double radHeading() {
        double heading = 0;

        heading = Math.toRadians(rawHeading());

        if ((heading <= 0) || (0 < heading && heading < Math.PI / 2)) {
            heading += Math.PI / 2;
        } else if (Math.PI / 2 <= heading) {
            heading -= 3 * (Math.PI / 2);
        }

        heading *= -1;

        return heading;
    }

    public void setArmLiftVelocity(double velocity) {
        leftArmLift.setVelocity(velocity);
        rightArmLift.setVelocity(velocity);
    }
}
