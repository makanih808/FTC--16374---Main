package org.firstinspires.ftc.teamcode.Constants;

public final class Names {
    // Drive Motor Names
    public static final String kFL = "front left";
    public static final String kFR = "front right";
    public static final String kBL = "back left";
    public static final String kBR = "back right";

    // System Motor Names
    public static final String kLeftArmLift = "left arm lift";
    public static final String kRightArmLift = "right arm lift";
    public static final String kIntakeMotor = "intake motor";
    public static final String kPixelLift = "pixel lift";

    // Servo Names
    public static final String kIntakeServo = "intake servo";
    public static final String kPlaneServo = "plane servo";
    public static final String kPixelServo = "pixel servo";

    // Sensor Names

    // Gyroscope
    public static final String kIMU = "imu";

    public static final String kWebCamera = "Webcam 1";
}
