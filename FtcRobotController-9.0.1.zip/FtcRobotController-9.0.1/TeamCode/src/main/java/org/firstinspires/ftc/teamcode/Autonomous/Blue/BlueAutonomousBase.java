package org.firstinspires.ftc.teamcode.Autonomous.Blue;

import com.qualcomm.robotcore.hardware.HardwareMap;

import org.firstinspires.ftc.robotcore.external.hardware.camera.WebcamName;
import org.firstinspires.ftc.teamcode.Components.BaseAutonomousSoftware;
import org.firstinspires.ftc.teamcode.Constants.CameraConstants;
import org.firstinspires.ftc.teamcode.Constants.Names;
import org.firstinspires.ftc.teamcode.Vision.CameraPipeline;
import org.openftc.easyopencv.OpenCvCamera;
import org.openftc.easyopencv.OpenCvCameraFactory;
import org.openftc.easyopencv.OpenCvCameraRotation;
import org.openftc.easyopencv.OpenCvWebcam;

public abstract class BlueAutonomousBase extends BaseAutonomousSoftware {

    private OpenCvWebcam webcam = null;

    public CameraPipeline pipeline = null;

    @Override
    public void initalize(HardwareMap hwMap) {
        super.initalize(hwMap);

        pipeline = new CameraPipeline(CameraPipeline.Color.BLUE);

        final int kCameraMonitorViewId = hardwareMap.appContext.getResources().getIdentifier(//
                "cameraMonitorViewId", "id", hwMap.appContext.getPackageName());

        webcam = OpenCvCameraFactory.getInstance().createWebcam(//
                hwMap.get(WebcamName.class, Names.kWebCamera), kCameraMonitorViewId);

        webcam.setPipeline(pipeline);

        webcam.openCameraDeviceAsync(new OpenCvCamera.AsyncCameraOpenListener() {
            @Override
            public void onOpened() {
                webcam.startStreaming(CameraConstants.kWidthResolution, CameraConstants.kHeightResolution, OpenCvCameraRotation.UPRIGHT);
            }

            @Override
            public void onError(int errorCode) {

            }
        });
    }
}
