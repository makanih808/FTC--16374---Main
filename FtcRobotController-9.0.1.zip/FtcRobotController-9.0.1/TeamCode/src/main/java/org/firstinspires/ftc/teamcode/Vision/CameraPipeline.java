package org.firstinspires.ftc.teamcode.Vision;

import org.firstinspires.ftc.teamcode.Constants.CameraConstants;
import org.opencv.core.Core;
import org.opencv.core.Mat;
import org.opencv.core.Rect;
import org.opencv.core.Scalar;
import org.opencv.imgproc.Imgproc;
import org.openftc.easyopencv.OpenCvPipeline;

public class CameraPipeline extends OpenCvPipeline {

    //Input matrix is a video frame we get from the camera
    //Keep the input matrix as is,
    //Create a working copy variable called mat
    Mat mat = new Mat();

    //Create a variable to store the result to access later in an op-mode

    public enum Color {RED, BLUE}
    public enum Location {LEFT, MIDDLE, RIGHT}

    private Color color;

    private Location location;

    static final Rect MiddleBox = new Rect(//
            CameraConstants.RectanglePositionConstants.kRectMiddlePointX,
            CameraConstants.RectanglePositionConstants.kRectMiddlePointY,
            CameraConstants.RectanglePositionConstants.kRectWidth,
            CameraConstants.RectanglePositionConstants.kRectLength);

    static final Rect RightBox = new Rect(//
            CameraConstants.RectanglePositionConstants.kRectRightPointX,
            CameraConstants.RectanglePositionConstants.kRectRightPointY,
            CameraConstants.RectanglePositionConstants.kRectWidth,
            CameraConstants.RectanglePositionConstants.kRectLength);

    public CameraPipeline(Color color) {this.color = color;}

    @Override
    public Mat processFrame (Mat input) {//
        //Convert matrix from RGB or BRG to HSV
        //RGB and BRG isn't so good for color detection

        int scaleToHSV = 0;

        switch (color) {
            case RED:
                scaleToHSV = Imgproc.COLOR_BGR2HSV;
                break;
            case BLUE:
                scaleToHSV = Imgproc.COLOR_RGB2HSV;
                break;
        }

        Imgproc.cvtColor(input, mat, scaleToHSV);

        //HSV value range
        //Data retrieved from here
        //https://stackoverflow.com/questions/36817133/identifying-the-range-of-a-color-in-hsv-using-opencv
        //x: hue 0-180, y: saturation 0-255 (0%-100%). z: values 0-255 (0%-100%).
        //Only if the HSV value at hand fits within all three ranges will be considered
        //If needed, use this website to play around with HSV values
        //Some websites have hue values that go from 0-360, in which case, convert yourself
        //https://www.peko-step.com/en/tool/hsvrgb_en.html
        Scalar lowRangeHSV = new Scalar(//
                CameraConstants.ColorRangeConstants.Low.kRed,
                CameraConstants.ColorRangeConstants.Low.kGreen,
                CameraConstants.ColorRangeConstants.Low.kBlue);
        Scalar highRangeHSV = new Scalar(//
                CameraConstants.ColorRangeConstants.High.kRed,
                CameraConstants.ColorRangeConstants.High.kGreen,
                CameraConstants.ColorRangeConstants.High.kBlue);

        //Apply thresholding to our image using the HSV range we just created
        //After thresholding, the matrix becomes a grayscale image;
        //The regions that have colors within the HSV range will turn white.
        //The rest will turn black.
        Core.inRange(mat, lowRangeHSV, highRangeHSV, mat);

        //Extract the boxes defined above from the image
        Mat middle = mat.submat(MiddleBox);
        Mat right = mat.submat(RightBox);

        //Check what percentage of the matrix became white
        //Add all pixels together, divide by its area, then divide by max value for a grayscale pixel 255
        double middleValue = Core.sumElems(middle).val[0] / MiddleBox.area() / 255;
        double rightValue = Core.sumElems(right).val[0] / RightBox.area() / 255;

        //Release them after the sub-matrices above are used
        middle.release();
        right.release();

        final boolean propMiddle = middleValue > 0.4;
        final boolean propRight = rightValue > 0.4;

        if (propMiddle) {//
            location = Location.MIDDLE;
        } else if (propRight) {//
            location = Location.RIGHT;
        } else {
            location = Location.LEFT;
        }

        //Draw rectangles to visualize the location of the team prop
        //Convert greyscale image back to RGB or BGR
        switch (color) {
            case RED:
                Imgproc.cvtColor(mat, mat, Imgproc.COLOR_GRAY2BGR);
                break;
            case BLUE:
                Imgproc.cvtColor(mat, mat, Imgproc.COLOR_GRAY2RGB);
                break;
        }

        //Use green if the prop is detected within the certain rectangle
        Scalar propDetected = new Scalar(0, 255, 0);
        Scalar propNotDetected = new Scalar(255,0,0);

        //Conditional Expression that chooses which color to use based on the location of the Team Prop

        Imgproc.rectangle(mat, MiddleBox, location == Location.MIDDLE ? propDetected : propNotDetected, 5);
        Imgproc.rectangle(mat, RightBox, location == Location.RIGHT ? propDetected : propNotDetected, 5);

        //Return the matrix which OpenCB will draw on the screen for us
        return mat;
    }

    public Location getLocation() {
        //Create a getter for the private location variable
        return location;
    }
}
