package org.firstinspires.ftc.teamcode.Constants;

public final class MotorConstants {
    public static final double kDriveMotorTicks = 517.7;
    public static final double kDriveMotorSpeedConstant = 2;
    public static final double kIntakeMotorTicks = 2800;
    public static final double kPixelLiftTicks = 1440;
    public static final double kPixelLiftUpPosition = 435;
    public class PIDConstants {
        public static final double kPixelLiftP = 0;
        public static final double kPixelLiftI = 0;
        public static final double kPixelLiftD = 0.1;
    }
    public static final double kArmLiftTicks = 3895.9;
    private static final double kArmLiftGearRatio = 18;
    public static final double kArmSpeedConstant = kArmLiftGearRatio;
    public static double kRotationFormula(double angle, double motorTicks) {
        final double kFormula = (motorTicks / 360);
        angle *= kFormula;
        return angle;
    }
}
