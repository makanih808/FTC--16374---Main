package org.firstinspires.ftc.teamcode.Constants;

import static org.firstinspires.ftc.robotcore.external.BlocksOpModeCompanion.hardwareMap;

public final class CameraConstants {

    public static final int kWidthResolution = 1280;
    public static final int kHeightResolution = 720;

    public static final class RectanglePositionConstants {
        // The constants are where the rectangles are placed on the screen;

        // Points for the Rectangle Middle
        public static final int kRectMiddlePointX = 295;
        public static final int kRectMiddlePointY = 310;

        // Points for Rectangle Right
        public static final int kRectRightPointX = 190;
        public static final int kRectRightPointY = 0;
        public static final int kRectWidth = 140;
        public static final int kRectLength = 190;
    }

    public static final class ColorRangeConstants {//
         public static final class Low {//
             public static final int kRed = 90;
             public static final int kGreen = 50;
             public static final int kBlue = 70;
         }

         public static final class High {
             public static final int kRed = 128;
             public static final int kGreen = 255;
             public static final int kBlue = 255;
        }
    }
}
