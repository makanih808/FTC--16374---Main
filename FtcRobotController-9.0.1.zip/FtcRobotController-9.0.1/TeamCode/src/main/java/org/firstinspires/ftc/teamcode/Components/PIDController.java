package org.firstinspires.ftc.teamcode.Components;

import com.qualcomm.robotcore.util.ElapsedTime;

public class PIDController {
    private double targetAngle = 0;
    private double kP = 0, kI = 0, kD = 0;
    private double accumulatedError = 0;
    private ElapsedTime timer = new ElapsedTime();
    private double lastError = 0;
    private double lastTime = 0;

    public PIDController(double targetAngle, double p, double i, double d) {
        this.targetAngle = targetAngle;
        kP = p;
        kI = i;
        kD = d;
    }

    public double update(double currentAngle) {
        double error = 0;

        error = targetAngle - currentAngle;
        error %= 360;
        error += 360;
        error %= 360;
        if (error > 180) error -= 360;

        accumulatedError += error;
        if (Math.abs(error) < 1) accumulatedError = 0;
        accumulatedError = Math.abs(accumulatedError) * Math.signum(error);

        double slope = 0;

        if (lastTime > 0) slope = (error - lastError) / (timer.milliseconds() / lastTime);
        lastError = error;
        lastTime = timer.milliseconds();

        double motorPower = 0;

        motorPower = 0.1 * Math.signum(error) + 0.9 * Math.tanh(//
                kP * error + kI * accumulatedError + kD * slope);

        return motorPower;
    }
}
