package org.firstinspires.ftc.teamcode.Autonomous.Red.Right;

import org.firstinspires.ftc.teamcode.Autonomous.Red.RedAutonomousBase;

//@Autonomous (name = "RR BB PR", group = "Red")
public class RedRightBoardBoardParkRight extends RedAutonomousBase {

    @Override
    public void runOpMode() throws InterruptedException {
        initalize(hardwareMap);

        waitForStart();

        if (opModeIsActive() && !isStopRequested()) {
            Movements(3.6, 1, Direction.FORWARD);
            sleep(1000);
            Movements(2.76, 1, Direction.STRAFE_LEFT);
            sleep(500);
            robot.intakeMotor.setPower(0.35);
            sleep(1500);
            robot.intakeMotor.setPower(0);
            liftingPixels(1, LiftDirection.UP);
            robot.pixelServo.setPower(-0.15);
            sleep(6500);
            robot.pixelServo.setPower(0);
            liftingPixels(1, LiftDirection.DOWN);
            Movements(0.5, 0.5, Direction.BACKWARD);
            sleep(500);
            Movements(2.25, 1, Direction.STRAFE_RIGHT);
            sleep(500);
            Movements(2.0, 1, Direction.FORWARD);
        }
    }
}
