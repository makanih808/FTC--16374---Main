package org.firstinspires.ftc.teamcode.Autonomous.Blue.Left;

import org.firstinspires.ftc.teamcode.Autonomous.Blue.BlueAutonomousBase;
import org.firstinspires.ftc.teamcode.Components.BaseAutonomousSoftware;

//@Autonomous (name = "BL BB PL", group = "Blue")
public class BlueLeftBoardBoardParkLeft extends BlueAutonomousBase {//

    @Override
    public void runOpMode() throws InterruptedException {//
        initalize(hardwareMap);

        waitForStart();

        if (opModeIsActive() && !isStopRequested()) {
            Movements(3.6, 1, Direction.FORWARD);
            sleep(1000);
            Movements(2.76, 1, Direction.STRAFE_RIGHT);
            sleep(500);
            robot.intakeMotor.setPower(0.35);
            sleep(1500);
            robot.intakeMotor.setPower(0);
            liftingPixels(1, LiftDirection.UP);
            robot.pixelServo.setPower(-0.15);
            sleep(6500);
            robot.pixelServo.setPower(0);
            liftingPixels(1, LiftDirection.DOWN);
            Movements(0.5, 0.5, Direction.BACKWARD);
            sleep(500);
            Movements(2.75, 1, Direction.STRAFE_LEFT);
            sleep(500);
            Movements(2.0, 1, Direction.FORWARD);
        }
    }
}
