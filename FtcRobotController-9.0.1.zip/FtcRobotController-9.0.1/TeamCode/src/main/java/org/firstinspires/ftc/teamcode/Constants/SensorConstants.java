package org.firstinspires.ftc.teamcode.Constants;

public final class SensorConstants {
        public static final byte kNAVX_DEVICE_UPDATE_RATE_HZ = 50;
}
