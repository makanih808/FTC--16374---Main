package org.firstinspires.ftc.teamcode.Constants;

public final class ServoConstants {
    // The rotation formula function is so that the input can go to an angle with a maximum of 270º.
    /* For example, I want the servos to go at a position 180º from 0º.
     * I input the angle at 180º and the formula calculates it at 180 / 270 = 0.667;
     * 0.667 then is the position the servo will go to.
     */
    public static double kRotationFormula(double angle) {
        final double kFormula = 1 / 270;

        if (angle > 270) {
            angle = 270 * kFormula;
        } else if (angle < 0) {
            angle = 0 * kFormula;
        } else {
            angle *= kFormula;
        }
        return angle;
    }
}
