package org.firstinspires.ftc.teamcode.Components;

import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.hardware.DcMotorEx;
import com.qualcomm.robotcore.hardware.HardwareMap;

import org.firstinspires.ftc.teamcode.Constants.MotorConstants;

public abstract class BaseAutonomousSoftware extends LinearOpMode {

    protected Hardware robot = null;

//    OpenCvCamera webcam;

//    public CameraPipeline pipeline = null;

    public enum Direction {//
        FORWARD, BACKWARD,
        STRAFE_LEFT, STRAFE_RIGHT,
        TURN_LEFT, TURN_RIGHT
    }

    public enum LiftDirection {UP, DOWN}
    public void initalize(HardwareMap hwMap) {//
        robot = new Hardware(hwMap, Hardware.Stage.AUTONOMOUS);
        robot.pixelLift.setMode(DcMotorEx.RunMode.RUN_USING_ENCODER);
    }

//    public void cameraInit(CameraPipeline.Color color) {
//        pipeline = new CameraPipeline(telemetry, color);
//        robot = new Hardware(hardwareMap, Hardware.Stage.AUTONOMOUS);
//
//        webcam = OpenCvCameraFactory.getInstance().createWebcam(//
//                hardwareMap.get(WebcamName.class, Names.kWebCamera), CameraConstants.kCameraMonitorViewId);
//
//        webcam.setPipeline(pipeline);
//        webcam.openCameraDeviceAsync(new OpenCvCamera.AsyncCameraOpenListener() {
//            @Override
//            public void onOpened() {//
//                webcam.startStreaming(CameraConstants.kLengthResolution, CameraConstants.kWidthResolution, OpenCvCameraRotation.UPRIGHT);
//            }
//
//            @Override
//            public void onError(int errorCode) {
//
//            }
//        });
//    }

    public void Movements(double rotation, double velocity, Direction direction) {//
        double flRotation = 0, frRotation = 0;
        double blRotation = 0, brRotation = 0;

        double flVelocity = 0, frVelocity = 0;
        double blVelocity = 0, brVelocity = 0;

        if (!isStopRequested()) {

            robot.fl.setMode(DcMotorEx.RunMode.STOP_AND_RESET_ENCODER);
            robot.fr.setMode(DcMotorEx.RunMode.STOP_AND_RESET_ENCODER);
            robot.bl.setMode(DcMotorEx.RunMode.STOP_AND_RESET_ENCODER);
            robot.br.setMode(DcMotorEx.RunMode.STOP_AND_RESET_ENCODER);

            robot.fl.setMode(DcMotorEx.RunMode.RUN_TO_POSITION);
            robot.fr.setMode(DcMotorEx.RunMode.RUN_TO_POSITION);
            robot.bl.setMode(DcMotorEx.RunMode.RUN_TO_POSITION);
            robot.br.setMode(DcMotorEx.RunMode.RUN_TO_POSITION);

            rotation *= MotorConstants.kDriveMotorTicks;
            velocity *= MotorConstants.kDriveMotorTicks;

            switch (direction) {
                case FORWARD:
                    flRotation = rotation;
                    frRotation = rotation;
                    blRotation = rotation;
                    brRotation = rotation;

                    flVelocity = velocity;
                    frVelocity = velocity;
                    blVelocity = velocity;
                    brVelocity = velocity;
                    break;
                case BACKWARD:
                    flRotation = -rotation;
                    frRotation = -rotation;
                    blRotation = -rotation;
                    brRotation = -rotation;

                    flVelocity = -velocity;
                    frVelocity = -velocity;
                    blVelocity = -velocity;
                    brVelocity = -velocity;
                    break;
                case STRAFE_LEFT:
                    flRotation = -rotation;
                    frRotation = rotation;
                    blRotation = rotation;
                    brRotation = -rotation;

                    flVelocity = -velocity;
                    frVelocity = velocity;
                    blVelocity = velocity;
                    brVelocity = -velocity;
                    break;
                case STRAFE_RIGHT:
                    flRotation = rotation;
                    frRotation = -rotation;
                    blRotation = -rotation;
                    brRotation = rotation;

                    flVelocity = velocity;
                    frVelocity = -velocity;
                    blVelocity = -velocity;
                    brVelocity = velocity;
                    break;
                case TURN_LEFT:
                    flRotation = -rotation;
                    frRotation = rotation;
                    blRotation = -rotation;
                    brRotation = rotation;

                    flVelocity = -velocity;
                    frVelocity = velocity;
                    blVelocity = -velocity;
                    brVelocity = velocity;
                    break;
                case TURN_RIGHT:
                    flRotation = rotation;
                    frRotation = -rotation;
                    blRotation = rotation;
                    brRotation = -rotation;

                    flVelocity = velocity;
                    frVelocity = -velocity;
                    blVelocity = velocity;
                    brVelocity = -velocity;
                    break;
            }

            robot.fl.setTargetPosition((int) flRotation);
            robot.fr.setTargetPosition((int) frRotation);
            robot.bl.setTargetPosition((int) blRotation);
            robot.br.setTargetPosition((int) brRotation);

            robot.fl.setVelocity(flVelocity);
            robot.fr.setVelocity(frVelocity);
            robot.bl.setVelocity(blVelocity);
            robot.br.setVelocity(brVelocity);
            while (robot.fl.isBusy() && robot.fr.isBusy() && robot.bl.isBusy() && robot.br.isBusy() && !isStopRequested()) {}
        }
    }

    public void turnPID(double angle) {
        if (!isStopRequested()) {
            robot.fl.setMode(DcMotorEx.RunMode.RUN_WITHOUT_ENCODER);
            robot.fr.setMode(DcMotorEx.RunMode.RUN_WITHOUT_ENCODER);
            robot.bl.setMode(DcMotorEx.RunMode.RUN_WITHOUT_ENCODER);
            robot.br.setMode(DcMotorEx.RunMode.RUN_WITHOUT_ENCODER);

            DriveTurnPID pid = null;

            pid = new DriveTurnPID(angle);

            pid.run();

            while (robot.fl.isMotorEnabled() && robot.fr.isMotorEnabled() && robot.bl.isMotorEnabled() && robot.br.isMotorEnabled() && !isStopRequested()) {
            }
        }
    }

    public void setIntakeMotorAngle(double angle, double velocity) {//
        if (!isStopRequested()) {//
            robot.intakeMotor.setMode(DcMotorEx.RunMode.RUN_USING_ENCODER);
            robot.intakeMotor.setMode(DcMotorEx.RunMode.STOP_AND_RESET_ENCODER);

            final double kFormula = angle * (MotorConstants.kIntakeMotorTicks / 360);
            velocity = Math.abs(velocity) * MotorConstants.kIntakeMotorTicks;

            if (angle < 0) {
                velocity *= -1;
            } else if (angle > 0) {
                velocity *= 1;
            } else {
                velocity = 0;
            }

            robot.intakeMotor.setTargetPosition((int) kFormula);
            robot.intakeMotor.setVelocity(velocity);
        }
    }

    public void liftingPixels(double velocity, LiftDirection liftDirection) {//
        if (!isStopRequested()) {//
            robot.pixelLift.setMode(DcMotorEx.RunMode.STOP_AND_RESET_ENCODER);
            robot.pixelLift.setMode(DcMotorEx.RunMode.RUN_TO_POSITION);

            double angle = 0;

            angle = (MotorConstants.kPixelLiftTicks / 360);
            velocity *= MotorConstants.kPixelLiftTicks;

            switch (liftDirection) {//
                case UP:
                    angle *= -MotorConstants.kPixelLiftUpPosition;
                    velocity *= -1;
                    break;
                case DOWN:
                    angle *= MotorConstants.kPixelLiftUpPosition;
                    velocity *= 1;
                    break;
            }

            robot.pixelLift.setTargetPosition((int) angle);
            robot.pixelLift.setVelocity(velocity);
        }
    }
}
