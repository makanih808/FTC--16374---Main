package org.firstinspires.ftc.teamcode.Autonomous.Blue.Left;

import org.firstinspires.ftc.teamcode.Autonomous.Blue.BlueAutonomousBase;

public abstract class BlueBackBoardPosBase extends BlueAutonomousBase {

    public enum StartPos {LEFT, MIDDLE, RIGHT}

    private StartPos startPos = null;

    public void pathing() {
        switch (startPos) {
            case LEFT:
                break;
            case MIDDLE:
                break;
            case RIGHT:
                break;
        }
    }

    private void leftPathing() {
        Movements(1.2, 2, Direction.BACKWARD);
        sleep(100);
        Movements(0.25, 1, Direction.STRAFE_RIGHT);
        sleep(100);

    }
}
