package org.firstinspires.ftc.teamcode.Components;

import com.qualcomm.robotcore.hardware.DcMotorEx;

import org.firstinspires.ftc.robotcore.external.navigation.AngleUnit;
import org.firstinspires.ftc.robotcore.external.navigation.AxesOrder;
import org.firstinspires.ftc.robotcore.external.navigation.AxesReference;

public class DriveTurnPID {//

    private Hardware robot = null;
    private static final double kP = 0;
    private static final double kI = 0;
    private static final double kD = 0;
    double degrees = 0;

    public DriveTurnPID(double degrees) {this.degrees = degrees;}

    private double getAbsoluteAngle() {//
        return robot.imu.getAngularOrientation(AxesReference.INTRINSIC, AxesOrder.ZYX, AngleUnit.DEGREES).firstAngle;
    }
    void turnToPID(double targetAngle) {//
        PIDController pid = new PIDController(targetAngle, kP, kI, kD);
        while (Math.abs(targetAngle - getAbsoluteAngle()) > 1) {
            double motorPower = pid.update(getAbsoluteAngle());
            robot.setDriveMotorPower(-motorPower, motorPower, -motorPower, motorPower);
        }
        robot.setAllDriveMotorPower(0);
    }

    public void run() {//
        turnToPID(degrees - getAbsoluteAngle());
    }
}
